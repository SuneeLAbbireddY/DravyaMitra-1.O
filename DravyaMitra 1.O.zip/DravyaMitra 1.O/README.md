# Concrete Mix Design Calculator

A comprehensive tool for concrete mix design calculations and strength prediction.

## Features

- Mix design calculations according to IS 456:2000 and IS 10262:2009
- Concrete strength prediction using machine learning
- Interactive visualization of results
- Mix design history tracking
- Cost calculation
- Temperature effects analysis
- Batch size calculator

## Installation

### For Users
1. Download the latest release from the releases section
2. Extract the zip file
3. Run the `concrete_calculator.exe` file

### For Developers
1. Clone this repository
2. Install Python 3.8 or higher
3. Install dependencies:
   ```bash
   pip install -r requirements/requirements.txt
   ```
4. Run the application:
   ```bash
   python src/mix_design_calculator_new.py
   ```

## Building from Source

To create a standalone executable:

1. Install PyInstaller:
   ```bash
   pip install pyinstaller
   ```
2. Run the build script:
   ```bash
   pyinstaller --onefile --windowed --icon=resources/icon.ico src/mix_design_calculator_new.py
   ```

## Usage

1. Enter the required parameters in the input fields
2. Click "Calculate Mix Design" to get the results
3. Use additional features through the menu bar:
   - Strength Predictor
   - Cost Calculator
   - Temperature Effects
   - Batch Calculator
   - Mix History

## License

This project is licensed under the MIT License - see the LICENSE file for details. 